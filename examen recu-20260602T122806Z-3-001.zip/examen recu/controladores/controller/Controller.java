package com.example.controladores.controller;

import com.example.controladores.model.Persona;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@RestController
@RequestMapping("/ws/personas")
public class Controller {

    
    private List<Persona> personas = new ArrayList<>();

    public void PersonaController() {
        // Datos de prueba
        personas.add(new Persona("Ana", "Martínez", 34));
        personas.add(new Persona("Luis", "Silva", 22));
        personas.add(new Persona("Carlos", "Gómez", 45));
        personas.add(new Persona("Silvia", "Martín", 15));
        personas.add(new Persona("Antonio", "Silva", 67));
    }

    // ==================== EJERCICIOS BÁSICOS ====================

    // GET /persona -> JSON
    @GetMapping(value = "/persona", produces = MediaType.APPLICATION_JSON_VALUE)
    public Persona getPersona() {
        return new Persona("manolo", "sosa", 45);
    }

    // GET /persona/xml -> XML
    @GetMapping(value = "/persona/xml", produces = MediaType.APPLICATION_XML_VALUE)
    public Persona getPersonaXML() {
        return personas.get(0);
    }

    // GET /listaPersonasJSON -> Lista JSON
    @GetMapping(value = "/listaPersonasJSON", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Persona> getPersonasJSON() {
        return personas;
    }

    // GET /listaPersonasXML -> Lista XML
    @GetMapping(value = "/listaPersonasXML", produces = MediaType.APPLICATION_XML_VALUE)
    public List<Persona> getPersonasXML() {
        return personas;
    }

    // ==================== EJ1: Búsqueda por nombre exacto ====================
    // GET /busca?nombre=ana -> JSON
    @GetMapping(value = "/busca", produces = MediaType.APPLICATION_JSON_VALUE)
    public Persona buscaPorNombre(@RequestParam String nombre) {
        Iterator<Persona> it = personas.iterator();

        while (it.hasNext()) {
            Persona p = it.next();
            if (p.getNombre() != null && p.getNombre().equalsIgnoreCase(nombre)) {
                return p;
            }
        }
        return null;
    }

    // ==================== EJ2: Mayores de edad (>=18) ====================
    // GET /mayores -> XML
    @GetMapping(value = "/mayores", produces = MediaType.APPLICATION_XML_VALUE)
    public List<Persona> getMayoresEdad() {
        List<Persona> resultado = new ArrayList<>();

        for (Persona p : personas) {
            if (p.getEdad() >= 18) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    // ==================== EJ3: Persona de mayor edad ====================
    // POST /mayor -> JSON
    @PostMapping(value = "/mayor", produces = MediaType.APPLICATION_JSON_VALUE)
    public Persona getPersonaMayor() {
        if (personas == null || personas.isEmpty()) {
            return null;
        }

        Persona mayor = null;
        Iterator<Persona> it = personas.iterator();

        while (it.hasNext()) {
            Persona actual = it.next();
            if (mayor == null || actual.getEdad() > mayor.getEdad()) {
                mayor = actual;
            }
        }
        return mayor;
    }

    // ==================== EJ4: Lista ordenada por edad o nombre ====================
    // GET /listapersonas?orden=edad|nombre -> XML
    @GetMapping(value = "/listapersonas", produces = MediaType.APPLICATION_XML_VALUE)
    public List<Persona> getPersonasOrdenadas(@RequestParam(required = false) String orden) {
        // Copia para no modificar el original
        List<Persona> copia = new ArrayList<>(personas);

        if ("edad".equalsIgnoreCase(orden)) {
            // Ordenación burbuja por edad (ascendente)
            for (int i = 0; i < copia.size() - 1; i++) {
                for (int j = 0; j < copia.size() - 1 - i; j++) {
                    if (copia.get(j).getEdad() > copia.get(j + 1).getEdad()) {
                        Persona temp = copia.get(j);
                        copia.set(j, copia.get(j + 1));
                        copia.set(j + 1, temp);
                    }
                }
            }
        } else if ("nombre".equalsIgnoreCase(orden)) {
            // Ordenación burbuja por nombre (ascendente, case-insensitive)
            for (int i = 0; i < copia.size() - 1; i++) {
                for (int j = 0; j < copia.size() - 1 - i; j++) {
                    if (copia.get(j).getNombre().compareToIgnoreCase(copia.get(j + 1).getNombre()) > 0) {
                        Persona temp = copia.get(j);
                        copia.set(j, copia.get(j + 1));
                        copia.set(j + 1, temp);
                    }
                }
            }
        }
        // Si orden es null o inválido, devuelve sin ordenar

        return copia;
    }

    // ==================== EJ5: Búsqueda parcial por apellido ====================
    // GET /autocompletar?termino=silva -> JSON
    @GetMapping(value = "/autocompletar", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Persona> buscarPorApellido(@RequestParam String termino) {
        List<Persona> resultado = new ArrayList<>();

        if (termino == null || termino.isEmpty()) {
            return resultado;
        }

        String terminoLower = termino.toLowerCase();

        for (Persona p : personas) {
            if (p.getApellidos() != null &&
                    p.getApellidos().toLowerCase().contains(terminoLower)) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    // ==================== EJ6: Filtrado por rango de edad ====================
    // GET /rango?min=20&max=40 -> XML
    @GetMapping(value = "/rango", produces = MediaType.APPLICATION_XML_VALUE)
    public List<Persona> getPorRangoEdad(
            @RequestParam String min,
            @RequestParam String max) {

        int minEdad, maxEdad;

        // Validación manual de parámetros
        try {
            minEdad = Integer.parseInt(min);
            maxEdad = Integer.parseInt(max);
        } catch (NumberFormatException e) {
            return new ArrayList<>(); // Lista vacía si error
        }

        if (minEdad > maxEdad) {
            return new ArrayList<>();
        }

        List<Persona> resultado = new ArrayList<>();

        for (Persona p : personas) {
            if (p.getEdad() >= minEdad && p.getEdad() <= maxEdad) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    // ==================== EJ7: Estadísticas ====================
    // POST /estadisticas -> JSON
    @PostMapping(value = "/estadisticas", produces = MediaType.APPLICATION_JSON_VALUE)
    public Estadisticas getEstadisticas() {
        if (personas == null || personas.isEmpty()) {
            return new Estadisticas(0, 0.0, 0);
        }

        int total = 0;
        int sumaEdades = 0;
        int edadMax = Integer.MIN_VALUE;

        for (Persona p : personas) {
            total++;
            sumaEdades += p.getEdad();
            if (p.getEdad() > edadMax) {
                edadMax = p.getEdad();
            }
        }

        double media = (double) sumaEdades / total;
        return new Estadisticas(total, media, edadMax);
    }

    // ==================== EJ8: Filtrado combinado (apellido + edad máxima) ====================
    // GET /buscar?apellido=silva&edadmax=30 -> XML
    @GetMapping(value = "/buscar", produces = MediaType.APPLICATION_XML_VALUE)
    public List<Persona> buscarCombinado(
            @RequestParam(required = false) String apellido,
            @RequestParam(required = false) String edadmax) {

        List<Persona> resultado = new ArrayList<>();

        // Parsear edad máxima (opcional)
        Integer edadMaxima = null;
        if (edadmax != null && !edadmax.isEmpty()) {
            try {
                edadMaxima = Integer.parseInt(edadmax);
            } catch (NumberFormatException e) {
                // Si hay error, ignoramos este filtro
            }
        }

        // Preparar filtro de apellido (opcional)
        String apellidoLower = null;
        if (apellido != null && !apellido.isEmpty()) {
            apellidoLower = apellido.toLowerCase();
        }

        for (Persona p : personas) {
            boolean cumpleApellido = true;
            boolean cumpleEdad = true;

            // Filtro por apellido (coincidencia parcial, case-insensitive)
            if (apellidoLower != null) {
                if (p.getApellidos() == null ||
                        !p.getApellidos().toLowerCase().contains(apellidoLower)) {
                    cumpleApellido = false;
                }
            }

            // Filtro por edad máxima
            if (edadMaxima != null && p.getEdad() > edadMaxima) {
                cumpleEdad = false;
            }

            if (cumpleApellido && cumpleEdad) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    // ==================== CLASE INTERNA PARA ESTADÍSTICAS ====================
    // (Puede ir en archivo separado, pero aquí para tener todo en uno)
    public static class Estadisticas {
        private int total;
        private double edadMedia;
        private int edadMaxima;

        public Estadisticas() {}

        public Estadisticas(int total, double edadMedia, int edadMaxima) {
            this.total = total;
            this.edadMedia = edadMedia;
            this.edadMaxima = edadMaxima;
        }

        public int getTotal() { return total; }
        public void setTotal(int total) { this.total = total; }

        public double getEdadMedia() { return edadMedia; }
        public void setEdadMedia(double edadMedia) { this.edadMedia = edadMedia; }

        public int getEdadMaxima() { return edadMaxima; }
        public void setEdadMaxima(int edadMaxima) { this.edadMaxima = edadMaxima; }
    }
}