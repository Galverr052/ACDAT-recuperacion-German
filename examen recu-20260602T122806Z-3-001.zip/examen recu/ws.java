package com.example.ejertipoexam;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;

@RestController
@RequestMapping("/ws/ex")
public class ws {

    @PostMapping("/hora")
    @ResponseBody
    public String hora (){
        LocalTime hora = LocalTime.now();

        return hora.format(DateTimeFormatter.ofPattern("HH:mm:ss"));
    }


    @GetMapping("/nveces")
    @ResponseBody
    public String secuencia(@RequestParam int min, @RequestParam int max) {

        if (min > max){
            return "El parámetro minimo debe ser menor o igual al máximo";
        }

        int[] numeros = new int[(max - min) + 1];

        for (int i = 0; i < numeros.length; i++) {
            numeros[i] = i + min;
        }

        return Arrays.toString(numeros);
    }

    @GetMapping(value = "/nveces", params = "frase" ,  produces = "application/xml")
    @ResponseBody
    public String frase(@RequestParam String frase) {

        StringBuilder xml = new StringBuilder();
        xml.append("<lista>");

        String procesados = "";

        for (char c : frase.toCharArray()) {

            if (procesados.indexOf(c) == -1) {
                int count = 0;

                for (char x : frase.toCharArray()) {
                    if (x == c) count++;
                }

                xml.append("<caracter>");
                xml.append("<simbolo>").append(c).append("</simbolo>");
                xml.append("<nveces>").append(count).append("</nveces>");
                xml.append("</caracter>");

                procesados += c;
            }
        }

        xml.append("</lista>");
        return xml.toString();

    }
    }
