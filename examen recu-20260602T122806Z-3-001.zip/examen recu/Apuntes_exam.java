package com.example.ejertipoexam;

public class Apuntes_exam {


    import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

    @RestController
    @RequestMapping("/ws/fecha")
    public class FechaController {

        /*
         * EJERCICIO 1: Devolver el día de la semana actual (ej: "Martes")
         * METHOD: GET, MIME: TEXT_PLAIN
         */
        @GetMapping(value = "/dia", produces = MediaType.TEXT_PLAIN_VALUE)
        @ResponseBody
        public String obtenerDiaSemana() {
            LocalDate hoy = LocalDate.now();

            // Obtenemos el día de la semana y lo formateamos en español
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEEE", new Locale("es", "ES"));
            // EEEE = nombre completo del día (ej: "martes"), E = letra inicial (ej: "M")

            return hoy.format(formatter).substring(0, 1).toUpperCase() + hoy.format(formatter).substring(1);
            // Nota: substring es para asegurar que empiece con mayúscula: "Martes"
        }

        /*
         * EJERCICIO 2: Devolver el número del día del mes (ej: "2") o el nombre del mes (ej: "Junio")
         * METHOD: GET, MIME: TEXT_PLAIN
         */
        @GetMapping(value = "/mes", produces = MediaType.TEXT_PLAIN_VALUE)
        @ResponseBody
        public String obtenerMes() {
            LocalDate hoy = LocalDate.now();

            // OPCIÓN A: Si piden el NÚMERO del mes (1 al 12)
            // int numeroMes = hoy.getMonthValue();
            // return String.valueOf(numeroMes);

            // OPCIÓN B: Si piden el NOMBRE del mes (Más común en exámenes)
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM", new Locale("es", "ES"));
            // MMMM = nombre completo ("junio"), MMM = abreviado ("jun")

            String mes = hoy.format(formatter);
            return mes.substring(0, 1).toUpperCase() + mes.substring(1); // "Junio"
        }

        /*
         * EJERCICIO 3: Devolver el año actual (ej: "2026")
         * METHOD: GET, MIME: TEXT_PLAIN
         *
         *
         *
         *
         *
         *
         */
        @GetMapping(value = "/anio", produces = MediaType.TEXT_PLAIN_VALUE)
        @ResponseBody
        public String obtenerAnio() {
            LocalDate hoy = LocalDate.now();

            // OPCIÓN A: Usando getter directo (la más sencilla y a prueba de fallos)
            int anio = hoy.getYear();
            return String.valueOf(anio);

            // OPCIÓN B: Usando DateTimeFormatter (también válida)
            // DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy");
            // return hoy.format(formatter);
        }
    }

    /*
     * EJERCICIO EXTRA: Devolver fecha completa en formato JSON manual
     * METHOD: GET, MIME: APPLICATION_JSON
     * Salida esperada: {"dia": "Martes", "mes": "Junio", "anio": 2026}
     */
    @GetMapping(value = "/completa", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public String obtenerFechaCompletaJSON() {
        LocalDate hoy = LocalDate.now();

        // 1. Obtener día con mayúscula inicial
        DateTimeFormatter formatterDia = DateTimeFormatter.ofPattern("EEEE", new Locale("es", "ES"));
        String dia = hoy.format(formatterDia);
        dia = dia.substring(0, 1).toUpperCase() + dia.substring(1);

        // 2. Obtener mes con mayúscula inicial
        DateTimeFormatter formatterMes = DateTimeFormatter.ofPattern("MMMM", new Locale("es", "ES"));
        String mes = hoy.format(formatterMes);
        mes = mes.substring(0, 1).toUpperCase() + mes.substring(1);

        // 3. Obtener año como número
        int anio = hoy.getYear();

        // 4. Construir el JSON manualmente (estilo examen seguro)
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"dia\": \"").append(dia).append("\", ");
        json.append("\"mes\": \"").append(mes).append("\", ");
        json.append("\"anio\": ").append(anio); // El año va sin comillas porque es un número en JSON
        json.append("}");

        return json.toString();
    }
}
